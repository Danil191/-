package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    val b1: Button=findViewById(R.id.button2)
    val t1:TextView=findViewById(R.id.textView)
    val t2:TextView=findViewById(R.id.textView2)
    val t3:TextView=findViewById(R.id.textView3)
    val t4:TextView=findViewById(R.id.textView4)
    val t5:TextView=findViewById(R.id.textView5)
    val t6:TextView=findViewById(R.id.textView6)
    val t7:TextView=findViewById(R.id.textView10)
    val t8:TextView=findViewById(R.id.textView7)
    val t9:TextView=findViewById(R.id.textView8)


    fun clear (textView1:TextView,textView2:TextView,textView3:TextView)
    {
        textView1.text = null
        textView2.text = null
        textView3.text = null
    }
    var a = 1
    var b = 1
    var c = 1
    var i = 0
    fun update (textView1: TextView, textView2: TextView, textView3: TextView) {
        textView1.text = (++a).toString()
        textView2.text = (++b).toString()
        textView3.text = (++c).toString()
    }
    b1.setOnClickListener{


        if (i % 3 == 0) {
            update(t1, t4, t8)
            clear(t2, t5, t9)
            clear(t3, t6, t7)
        }

        if (i % 3 == 1) {
            update(t2, t5, t9)
            clear(t1, t4, t8)
            clear(t3, t6, t7)
        }

        if (i % 3 == 2) {
            update(t3, t6, t7)
            clear(t2, t5, t9)
            clear(t1, t4, t8)
        }
        ++i
    }
}}